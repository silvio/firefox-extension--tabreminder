import { TimeReminder } from '../types';
declare class AlarmService {
    private hasTriggeredOccurrence;
    private addTriggeredReminderIfNeeded;
    scheduleReminder(reminder: TimeReminder): Promise<void>;
    cancelReminder(reminderId: string): Promise<void>;
    rescheduleAllReminders(): Promise<void>;
    scheduleNoteReminder(note: any): Promise<void>;
    cancelNoteReminder(noteId: string): Promise<void>;
    handleAlarm(alarmName: string): Promise<void>;
    private handleNoteReminder;
    private showNotification;
    updateTriggeredBadge(): Promise<void>;
    getDueReminders(): Promise<TimeReminder[]>;
}
export declare const alarmService: AlarmService;
export {};
//# sourceMappingURL=alarms.d.ts.map