import { WebDAVClient } from 'webdav';
import { CategoryFile } from '../types';
export declare class WebDAVError extends Error {
    code?: string | undefined;
    constructor(message: string, code?: string | undefined);
}
export declare class WebDAVAuthError extends WebDAVError {
    constructor(message?: string);
}
export declare class WebDAVNetworkError extends WebDAVError {
    constructor(message?: string);
}
declare class WebDAVService {
    private client;
    private config;
    initClient(url: string, username: string, password: string, basePath?: string): void;
    getClient(): WebDAVClient;
    testConnection(): Promise<boolean>;
    ensureBasePath(basePath?: string): Promise<void>;
    getFile(filename: string): Promise<CategoryFile | null>;
    putFile(filename: string, data: CategoryFile): Promise<void>;
    deleteFile(filename: string): Promise<void>;
    fileExists(filename: string): Promise<boolean>;
    listCategoryFiles(): Promise<Array<{
        filename: string;
        categoryId: string;
        categoryName: string;
    }>>;
    sanitizeFilename(name: string): string;
    buildFilename(categoryId: string): string;
    buildOldFilename(categoryName: string): string;
}
export declare const webdavService: WebDAVService;
export {};
//# sourceMappingURL=webdav.d.ts.map