export type UrlMatchType = 'exact' | 'path' | 'domain' | 'regex';
export interface Category {
    id: string;
    name: string;
    color: string;
    isDefault: boolean;
    webdavSync?: boolean;
    lastSyncTime?: number;
    updatedAt?: number;
}
export interface PageNote {
    id: string;
    url: string;
    urlMatchType: UrlMatchType;
    title: string;
    content: string;
    categoryId: string | null;
    createdAt: number;
    updatedAt: number;
    version?: number;
    hasReminder?: boolean;
    scheduleType?: ScheduleType;
    scheduledTime?: number | null;
    recurringPattern?: RecurringPattern | null;
    nextTrigger?: number;
    deleted?: boolean;
    deletedAt?: number;
    hardDeleted?: boolean;
    hardDeletedAt?: number;
}
export type ScheduleType = 'once' | 'recurring';
export type FrequencyType = 'seconds' | 'minutes' | 'hours' | 'daily' | 'weekly' | 'monthly' | 'yearly';
export type EndCondition = {
    type: 'never';
} | {
    type: 'date';
    endDate: number;
} | {
    type: 'count';
    occurrences: number;
};
export interface RecurringPattern {
    frequency: FrequencyType;
    interval: number;
    weekdays?: number[];
    dayOfMonth?: number;
    weekdayOrdinal?: {
        ordinal: number;
        weekday: number;
    };
    endCondition: EndCondition;
    exceptions?: number[];
    timeOfDay?: {
        hour: number;
        minute: number;
    };
}
export interface TimeReminder {
    id: string;
    url: string;
    title: string;
    scheduleType: ScheduleType;
    scheduledTime: number | null;
    recurringPattern: RecurringPattern | null;
    nextTrigger: number;
    categoryId: string | null;
    createdAt: number;
}
export interface OverlayStyle {
    backgroundColor: string;
    borderColor: string;
    borderWidth?: number;
    fontSize?: number;
    fontFamily?: string;
    timeout?: number;
    opacity?: number;
}
export interface NotificationSettings {
    system: boolean;
    overlay: boolean;
    badge: boolean;
    overlayStyle: OverlayStyle;
}
export interface SyncedSettings {
    syncEnabled: boolean;
    notifications: NotificationSettings;
    preselectLastCategory: boolean;
    popupHeight: number;
    editViewMode: 'tab' | 'modal';
    webdavUrl?: string;
    webdavEnabled?: boolean;
    categoryColors?: {
        [categoryId: string]: string;
    };
}
export interface LocalSettings {
    lastDeleteAllTimestamp?: number;
    lastUsedCategoryId?: string;
    webdavUsername?: string;
    webdavPassword?: string;
    webdavBasePath?: string;
    webdavSyncInterval?: number;
    webdavLastSync?: number;
    webdavSyncErrors?: string | {
        message: string;
        timestamp: number;
    };
}
export interface Settings extends SyncedSettings, LocalSettings {
}
export interface WebDAVOutboxEntry {
    categoryId: string;
    attempts: number;
    nextAttemptAt: number;
    lastAttemptAt?: number;
    lastError?: string;
}
export type WebDAVOutboxState = Record<string, WebDAVOutboxEntry>;
export interface CategoryFile {
    version: number;
    categoryId: string;
    categoryName: string;
    categoryColor: string;
    notes: PageNote[];
    lastModified: number;
}
export interface TriggeredReminder {
    id: string;
    reminderId: string;
    url: string;
    title: string;
    triggeredAt: number;
    dismissed: boolean;
}
export interface StorageData {
    notes: PageNote[];
    reminders: TimeReminder[];
    categories: Category[];
    settings: Settings;
    triggeredReminders: TriggeredReminder[];
}
export declare const DEFAULT_CATEGORIES: Category[];
export declare const DEFAULT_SETTINGS: Settings;
//# sourceMappingURL=index.d.ts.map