import { PageNote, RecurringPattern, ScheduleType } from '../types';
export type NoteReminderFields = Pick<PageNote, 'hasReminder' | 'scheduleType' | 'scheduledTime' | 'recurringPattern' | 'nextTrigger'>;
export interface BuildReminderFieldsInput {
    editingNote?: PageNote | null;
    hasReminder: boolean;
    scheduleType: ScheduleType;
    scheduledTime?: number | null;
    recurringPattern?: RecurringPattern | null;
    preserveRecurringWithoutPattern?: boolean;
}
export declare function buildReminderFields({ editingNote, hasReminder, scheduleType, scheduledTime, recurringPattern, preserveRecurringWithoutPattern, }: BuildReminderFieldsInput): NoteReminderFields;
//# sourceMappingURL=reminderFields.d.ts.map