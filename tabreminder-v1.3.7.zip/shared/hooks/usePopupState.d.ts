interface PopupState {
    activeTab: string;
    noteTitle: string;
    noteContent: string;
    noteUrlMatchType: string;
    noteCategoryId: string;
    noteMatchUrl: string;
    reminderTitle: string;
    reminderTimeInput: string;
    reminderCategoryId: string;
    reminderMatchUrl: string;
    filterCategory: string;
}
export declare function usePopupState(): {
    state: PopupState;
    updateState: (partial: Partial<PopupState>) => void;
    resetNoteForm: () => void;
    resetReminderForm: () => void;
};
export {};
//# sourceMappingURL=usePopupState.d.ts.map