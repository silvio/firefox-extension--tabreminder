export type Platform = 'desktop' | 'android';
/**
 * Detect if running on Android Firefox
 */
export declare function isAndroid(): boolean;
/**
 * Check if alarms API is available (runtime check for optional permission)
 */
export declare function hasAlarmSupport(): boolean;
/**
 * Check if background sync should be enabled
 */
export declare function hasBackgroundSync(): boolean;
/**
 * Check if notifications API is available (runtime check for optional permission)
 */
export declare function hasNotificationSupport(): boolean;
/**
 * Get current platform
 */
export declare function getPlatform(): Platform;
//# sourceMappingURL=platform.d.ts.map