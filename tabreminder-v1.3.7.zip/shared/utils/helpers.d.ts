import { PageNote, TimeReminder, UrlMatchType } from '../types';
export declare function createNote(url: string, title: string, content: string, urlMatchType?: UrlMatchType, categoryId?: string | null): PageNote;
export declare function createReminder(url: string, title: string, nextTrigger: number, categoryId?: string | null): TimeReminder;
export declare function normalizeUrl(url: string): string;
export declare function extractDomain(url: string): string;
export declare function extractPath(url: string): string;
export declare function getUrlMatchPreview(url: string, matchType: UrlMatchType): string;
//# sourceMappingURL=helpers.d.ts.map