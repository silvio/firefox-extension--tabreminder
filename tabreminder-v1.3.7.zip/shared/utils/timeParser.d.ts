import { RecurringPattern } from '../types';
export interface ParsedTime {
    timestamp: number;
    isRecurring: boolean;
    recurringPattern: RecurringPattern | null;
    displayText: string;
}
export declare function parseTimeInput(input: string): ParsedTime | null;
export declare function getIntervalMs(interval: number, unit: string): number;
export declare function calculateNextTrigger(pattern: RecurringPattern, fromDate?: number): number;
export declare function formatDate(date: Date): string;
export declare function formatRelativeTime(timestamp: number): string;
export declare function getNextOccurrences(pattern: RecurringPattern, count?: number): number[];
export declare function describeRecurringPattern(pattern: RecurringPattern): string;
//# sourceMappingURL=timeParser.d.ts.map