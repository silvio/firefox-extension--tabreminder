
When you do changes, always:
- Changes should be small as possible. This means no changes in style or
  formating if it isn't needed.
- When you do some stuff, all stuff should have a `git commit` with a `date
  --iso8601=s` timestamp in it.
  - Every commit of a serie should have the same timestamp. A question which
    ends in several changes, has the same timestamp. I want to recognize the
    doing on the sources.
  - Another question means a new timestamp.
  - Format is: `copilot: (<DATE>) <summary>`
  - The commit message should contain the plan and the part which is done in
    this commit.
    - Use follwoing syntax:
      - `[ ]` means open task
      - `[x]` means task is already done
      - `[>]` means current task
- belong to the current datamodel. If you want to change the datamodel, you have
  to ask with a explanation what exactly you want to change. The topmost
  priority is not to lose reminders / notes / ...


## Path specific rules:

Following rules for python files: `**/*.py`:

- Empty lines should not have spaces for indentation
- The linter should disable the warning of 80charactes of a line

