Evolution’s recurrence dialog lets a user tell the calendar “how often, and until when” an appointment or meeting repeats, plus which individual dates are excluded. For a web implementation, you mainly need controls for a repeat pattern, an end condition, and exceptions.
Where recurrence is opened

    In the appointment/meeting editor there is a Recurrence button or a menu item like Options → Recurrence that opens a separate recurrence dialog.

    Recurrence is defined per event; if the event “takes place regularly” the user opens this dialog and configures the rule.

Core recurrence model

Evolution’s UI essentially builds a natural-language sentence from left to right, such as “Every two weeks on Monday and Friday until January 3, 2015” or “Every month on the first Friday for 12 occurrences.” To mirror this in a web UI, you need these logical parts:

    A checkbox or switch “This appointment recurs” to enable/disable recurrence.

    Frequency selector: daily, weekly, monthly, yearly (plus “no recurrence”).

    Interval: numeric “every N” (e.g. every 2 weeks, every 3 months, every 10 years, up to very large intervals such as 100 years).

    Pattern details depending on frequency:

        Daily: every N days.

        Weekly: every N weeks on specific weekdays (check boxes Monday–Sunday).

        Monthly:

            “On day X of every N months” (e.g. day 15 every 1 month).

            Or “On the Nth <weekday> of every M months” (e.g. 3rd Thursday every month).

        Yearly: similar idea, but by month + day or “Nth weekday of month” pattern.

End condition (“range of recurrence”)

The dialog lets the user specify when the repeating series stops.

    Start is taken from the event’s start date/time.

    End options:

        “No end date” (repeat forever).

        “End by” specific date (calendar picker).

        “End after N occurrences” (integer count).

Exceptions (individual dates)

The recurrence UI also supports exceptions, i.e., dates where this event does not occur even though the rule says it would.

    There is an “Exceptions” area where the user can:

        Add specific dates to skip (for holidays, one-off cancellations, etc.).

        Remove exception dates again to “re‑enable” that occurrence.

    All exceptions are bound to the base recurring series, not to separate events.

Suggested web UI structure

To implement something analogous on a webpage for recurring meetings, you can structure your form like this (mirroring Evolution’s semantics):

    Recurrence toggle

        Checkbox: “Repeat this meeting” (unchecked → no recurrence configuration visible).

    Pattern row (sentence builder)

        “Repeat” [frequency select: None, Daily, Weekly, Monthly, Yearly].

        “Every” [number input: interval] [unit label updates with frequency].

        Frequency-specific controls:

            Daily: just the interval.

            Weekly: “On” [weekday checkboxes].

            Monthly:

                Radio 1: “On day [number] of every [interval] month(s)”.

                Radio 2: “On the [1st/2nd/3rd/4th/last] [weekday] of every [interval] month(s)”.

            Yearly: similar radios using month + day or ordinal weekday in a month.

    End condition row

        Options group:

            “Never end”.

            “End by [date picker]”.

            “End after [number] occurrences”.

    Exceptions section

        Label “Exceptions (dates when the meeting does not occur)”.

        Control to “Add date” → date picker, populates a list.

        List of exception dates with remove buttons.

    Preview sentence (optional but very Evolution-like)

        Read-only text built from the chosen options, for example:

            “Every 2 weeks on Monday and Friday until 03 Jan 2028” or

            “Every month on the first Friday for 12 occurrences”.

This captures the functional behavior of Evolution’s recurrence page and can serve directly as a specification for a recurring meeting configuration component.
